using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class EQUIPCONTROLLER : MonoBehaviour
{
    [Header("�г�")]
    public GameObject equipPanel;
    public GameObject listPopup;

    [Header("����")]
    public ITEMSLOT[] plantSlots;
    public ITEMSLOT animalSlot;

    [Header("���")]
    public ITEMDATABASE database;
    public Transform listContainer;
    public Button listItemPrefab;

    [Header("�̵��� ��")]
    public string nextSceneName = "SampleScene";

    ITEMSLOT currentSlot;

    void Start()
    {
        equipPanel.SetActive(false);
        listPopup.SetActive(false);
    }

    public void OpenEquipPanel()
    {
        System.Array.Clear(GAMEDATA.Plants, 0, GAMEDATA.Plants.Length);
        GAMEDATA.Animal = null;
        foreach (var s in plantSlots) s.SetItem(null);
        animalSlot.SetItem(null);
        equipPanel.SetActive(true);
    }

    public void OpenList(ITEMSLOT slot)
    {
        currentSlot = slot;
        foreach (Transform c in listContainer) Destroy(c.gameObject);

        foreach (ITEMDATA item in database.GetByType(slot.type))
        {
            ITEMDATA it = item;
            Button b = Instantiate(listItemPrefab, listContainer);
            b.gameObject.SetActive(true);
            b.GetComponentInChildren<Text>().text = it.itemName;
            b.onClick.AddListener(() => SelectItem(it));

        }
        listPopup.SetActive(true);
        foreach (ITEMDATA item in database.GetByType(slot.type))
        {
            if (!INVENTORY.IsOwned(item)) continue;
            ITEMDATA it = item;
        }

        void SelectItem(ITEMDATA item)
        {
            if (currentSlot.type == ITEMTYPE.Plant)
            {
                foreach (var p in GAMEDATA.Plants)
                    if (p == item) return;   // ���� �Ĺ� �ߺ� ����
                GAMEDATA.Plants[currentSlot.index] = item;
            }
            else
            {
                GAMEDATA.Animal = item;
            }
            currentSlot.SetItem(item);
            listPopup.SetActive(false);
        }
    }

    public void CloseList() { listPopup.SetActive(false); }
    public void BackToSubStage() { equipPanel.SetActive(false); }

    public void OnStart()
    {
        SceneManager.LoadScene(nextSceneName);
    }
}