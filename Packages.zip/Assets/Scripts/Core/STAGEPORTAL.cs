using UnityEngine;
using UnityEngine.SceneManagement;

public class STAGEPORTAL : INTERACTABLE
{
    public string sceneName = "STAGESELECT";

    void Reset() { promptName = "�������� ����"; }

    public override void Interact()
    {
        SceneManager.LoadScene(sceneName);
    }
}